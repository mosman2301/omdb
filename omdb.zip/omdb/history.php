<?php
  $nav_selected = "HISTORY";
  $left_buttons = "NO";
  $left_selected = "";

  include("./nav.php");
  
 ?>

 <div class="right-content">
    <div class="container">

      <h3 style = "color: #01B0F1;">History (TO BE DONE LATER)</h3>

    </div>
</div>

<?php include("./footer.php"); ?>
