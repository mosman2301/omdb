<?php

DEFINE('DB_SERVER', 'localhost');
DEFINE('DB_NAME', 'omdb');
DEFINE('DB_USER', 'root');
DEFINE('DB_PASS', '');

?>
